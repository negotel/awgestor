<?php
class TestHook{
	function TestH(){
	    
	    $CI=get_instance();
	    
	}
}