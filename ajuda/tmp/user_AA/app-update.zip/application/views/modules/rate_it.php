<script type="text/javascript">
    alert("ok");
</script>