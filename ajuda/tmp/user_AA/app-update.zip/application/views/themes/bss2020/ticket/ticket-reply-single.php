<?php
/**
 * @var $reply_object;
 * @var $ticket_user_id;
 */
echo GetTicketReplyHTML2020($reply_object,$ticket_user_id);