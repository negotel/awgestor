<?php
echo $action_data;