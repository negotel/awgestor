<?php
echo $addon_html;