<?php
$config['google_app_name']="APP licensor";
$config['client_id'] = '137396854606-47j3a40605s3unkacq1r253ncjcuknc6.apps.googleusercontent.com';
$config['client_secret'] = 'm5YgQR6j4HzkxibIrlcvr-CX';