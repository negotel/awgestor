<?php
//silance is golder